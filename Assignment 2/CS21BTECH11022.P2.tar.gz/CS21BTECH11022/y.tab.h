/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    SCOPE = 258,
    DATATYPE = 259,
    UDATATYPE = 260,
    ID = 261,
    CHARS = 262,
    STRINGS = 263,
    BOOLS = 264,
    INTS = 265,
    VOID = 266,
    DECLARE = 267,
    EXPR = 268,
    CALL = 269,
    IF = 270,
    ELSE = 271,
    DO = 272,
    WHILE = 273,
    FOR = 274,
    POSTINCR = 275,
    POSTDECR = 276,
    LT = 277,
    GT = 278,
    GEQ = 279,
    LEQ = 280,
    NE = 281,
    EQ = 282,
    NOT = 283,
    AND = 284,
    OR = 285,
    LPAREN = 286,
    RPAREN = 287,
    LBRACE = 288,
    RBRACE = 289,
    LSQUARE = 290,
    RSQUARE = 291,
    SEMICOLON = 292,
    COMMA = 293,
    ARROW = 294,
    ADD = 295,
    SUB = 296,
    MULT = 297,
    DIV = 298,
    ASSIGN = 299,
    RETURN = 300,
    CLASS = 301,
    THIS = 302,
    LOWER_THAN_ELSE = 303
  };
#endif
/* Tokens.  */
#define SCOPE 258
#define DATATYPE 259
#define UDATATYPE 260
#define ID 261
#define CHARS 262
#define STRINGS 263
#define BOOLS 264
#define INTS 265
#define VOID 266
#define DECLARE 267
#define EXPR 268
#define CALL 269
#define IF 270
#define ELSE 271
#define DO 272
#define WHILE 273
#define FOR 274
#define POSTINCR 275
#define POSTDECR 276
#define LT 277
#define GT 278
#define GEQ 279
#define LEQ 280
#define NE 281
#define EQ 282
#define NOT 283
#define AND 284
#define OR 285
#define LPAREN 286
#define RPAREN 287
#define LBRACE 288
#define RBRACE 289
#define LSQUARE 290
#define RSQUARE 291
#define SEMICOLON 292
#define COMMA 293
#define ARROW 294
#define ADD 295
#define SUB 296
#define MULT 297
#define DIV 298
#define ASSIGN 299
#define RETURN 300
#define CLASS 301
#define THIS 302
#define LOWER_THAN_ELSE 303

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
